# PyroCMS Simple Store Module
This Simple Store module is developed from the [Products Module](https://github.com/patrickkivits/PyroCMS-Products-Module) made by [Patrick Kivits](http://twitter.com/patrickkivits).
I choose to make new repository because there are a lot of custom changes and additional feature such as cart etc.

## Team
* [Toni Haryanto](http://toniharyanto.com)
* [Eko Muhammad Isa](https://github.com/ekoisa)

## Versions
* v1.0 - Initial version. 

## IMPORTANT
This version is under develop and unstable, until we create any tag for download place.
If you have install it and want to update the changes, make sure you backup your data first. We haven't create version upgrade functionality in this module.
