<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Blog Permissions
$lang['products.role_manage_orders']		= 'Manage Orders';
$lang['products.role_manage_custom_fields']	= 'Manage Custom Fields';
$lang['products.role_manage_specials']	 	= 'Delete Manage Specials';
