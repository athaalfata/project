<?php
//messages
$lang['categories:no_items']	=	'Geen categorieën gevonden.';

//page titles
$lang['categories:create']		=	'Voeg categorie toe';
$lang['categories:edit']		=	'Wijzig een categorie';

//labels
$lang['categories:name']			=	'Naam';
$lang['categories:description']		=	'Omschrijving';
$lang['categories:item_list']		=	'Categorieën lijst';
?>