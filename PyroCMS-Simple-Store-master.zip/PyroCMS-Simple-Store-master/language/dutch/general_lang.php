<?php
//messages
$lang['general:success']		=	'Gelukt!';
$lang['general:error']			=	'Er is iets mis gegaan.';

//labels
$lang['general:manage']		=	'Beheer';
$lang['general:add']		=	'Toevoegen';
$lang['general:view']		=	'Bekijk';
$lang['general:edit']		=	'Wijzig';
$lang['general:delete']		=	'Verwijder';

// Tabs
$lang['specials:label']		=	'Aanbiedingen';
$lang['products:label']		=	'Producten';
$lang['categories:label']	=	'Categorieën';
$lang['fields:label']		=	'Eigen velden';
?>