<?php
//messages
$lang['fields:no_items']	=	'Geen eigen velden gevonden.';

//page titles
$lang['fields:create']		=	'Voeg eigen veld toe';
$lang['fields:edit']		=	'Wijzig een eigen veld';

//labels
$lang['fields:name']			=	'Naam';
$lang['fields:type']			=	'Type';
$lang['fields:item_list']		=	'Eigen velden list';

// Options
$lang['fields:option:text']		=	'Text';
$lang['fields:option:textarea']	=	'Textarea';
?>