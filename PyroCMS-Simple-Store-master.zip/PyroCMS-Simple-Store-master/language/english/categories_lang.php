<?php
//messages
$lang['categories:no_items']	=	'No categories found';

//page titles
$lang['categories:create']		=	'Add a category';
$lang['categories:edit']		=	'Edit a categorie';

//labels
$lang['categories:name']			=	'Name';
$lang['categories:description']		=	'Description';
$lang['categories:item_list']		=	'Categories list';
?>
