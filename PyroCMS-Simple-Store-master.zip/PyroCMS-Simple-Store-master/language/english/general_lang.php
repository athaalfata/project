<?php
//messages
$lang['general:success']		=	'Success!';
$lang['general:error']			=	'Something went wrong.';

//labels
$lang['general:manage']		=	'Manage';
$lang['general:add']		=	'Add';
$lang['general:view']		=	'View';
$lang['general:edit']		=	'Edit';
$lang['general:delete']		=	'Delete';

// Tabs
$lang['specials:label']		=	'Specials';
$lang['products:label']		=	'Products';
$lang['categories:label']	=	'Categories';
$lang['fields:label']		=	'Custom fields';
$lang['orders:label']		=	'Orders';
$lang['settings:label']		=	'Settings';
?>
