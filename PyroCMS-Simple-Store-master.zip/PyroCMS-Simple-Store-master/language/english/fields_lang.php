<?php
//messages
$lang['fields:no_items']	=	'No custom fields found.';

//page titles
$lang['fields:create']		=	'Add a custom field';
$lang['fields:edit']		=	'Edit a custom field';

//labels
$lang['fields:name']			=	'Name';
$lang['fields:type']			=	'Type';
$lang['fields:item_list']		=	'Fields list';

// Options
$lang['fields:option:text']		=	'Text';
$lang['fields:option:textarea']	=	'Textarea';
?>