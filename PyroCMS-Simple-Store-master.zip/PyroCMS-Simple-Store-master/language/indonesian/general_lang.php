<?php
//messages
$lang['general:success']		=	'Berhasil!';
$lang['general:error']			=	'Terjadi kesalahan.';

//labels
$lang['general:manage']		=	'Atur';
$lang['general:add']		=	'Tambah';
$lang['general:view']		=	'Lihat';
$lang['general:edit']		=	'Edit';
$lang['general:delete']		=	'Hapus';

// Tabs
$lang['specials:label']		=	'Spesial';
$lang['products:label']		=	'Produk';
$lang['categories:label']	=	'Kategori';
$lang['fields:label']		=	'Field Tambahan';
$lang['orders:label']		=	'Pesanan';
$lang['settings:label']		=	'Pengaturan';
?>
