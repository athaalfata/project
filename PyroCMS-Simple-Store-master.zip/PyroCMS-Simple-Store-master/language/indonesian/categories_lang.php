<?php
//messages
$lang['categories:no_items']	=	'Tidak ada kategori';

//page titles
$lang['categories:create']		=	'Tambah Kategori';
$lang['categories:edit']		=	'Edit Kategori';

//labels
$lang['categories:name']			=	'Nama';
$lang['categories:description']		=	'Deskripsi';
$lang['categories:item_list']		=	'Daftar Kategori';
?>
