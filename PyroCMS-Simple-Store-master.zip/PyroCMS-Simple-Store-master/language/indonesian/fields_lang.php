<?php
//messages
$lang['fields:no_items']	=	'Tidak ada field tambahan';

//page titles
$lang['fields:create']		=	'Tambah field tambahan';
$lang['fields:edit']		=	'Edit field tambahan';

//labels
$lang['fields:name']			=	'Nama';
$lang['fields:type']			=	'Tipe';
$lang['fields:item_list']		=	'Daftar Field';

// Options
$lang['fields:option:text']		=	'Text';
$lang['fields:option:textarea']	=	'Textarea';
?>
