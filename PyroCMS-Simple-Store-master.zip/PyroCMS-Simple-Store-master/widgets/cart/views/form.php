<ol>

    <li class="<?php echo alternator('even', ''); ?>">
        <label for="checkout_caption">Checkout Caption</label>
        <?php echo form_input('checkout_caption', $options['checkout_caption']); ?>
    </li>

</ol>
